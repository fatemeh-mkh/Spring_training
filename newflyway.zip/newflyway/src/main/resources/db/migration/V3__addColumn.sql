ALTER TABLE family_table
ADD COLUMN details varchar(250);
