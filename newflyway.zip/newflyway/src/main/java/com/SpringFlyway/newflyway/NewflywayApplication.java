package com.SpringFlyway.newflyway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewflywayApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewflywayApplication.class, args);
	}

}
