package com.SpringFlyway.newflyway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewflywayApplicationTests {

	@Test
	void contextLoads() {
	}

}
